
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ramisanhory',
  applicationName: 'demo-app',
  appUid: '9QV3Zt9SmBJ2cX5psz',
  orgUid: '7d41fcca-9ef0-42c7-a3f0-1ea071723030',
  deploymentUid: '716e84d6-c78c-4733-a12c-e76c15641827',
  serviceName: 'myserverlessproject',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'myserverlessproject-dev-createPlayerScore', timeout: 6 };

try {
  const userHandler = require('./lambdas/endpoints/createPlayerScore.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}