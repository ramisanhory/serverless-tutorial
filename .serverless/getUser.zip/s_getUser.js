
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ramisanhory',
  applicationName: 'demo-app',
  appUid: '9QV3Zt9SmBJ2cX5psz',
  orgUid: '7d41fcca-9ef0-42c7-a3f0-1ea071723030',
  deploymentUid: '58ed8949-77e5-43d9-bbb4-1aefff742fd4',
  serviceName: 'myserverlessproject',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'myserverlessproject-dev-getUser', timeout: 6 };

try {
  const userHandler = require('./lambdas/endpoints/getUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}